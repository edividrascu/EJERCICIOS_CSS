Replicate the layout present in asset/layout1.png, using CSS Flexbox property.
**Suggestion:**
Look at video about the CSS Flexbox property
