Try to replicate the layout in asset/layout4.png, using CSS Grid properties. The green and orange blocks are half as high as the yellow and red blocks.

**Suggestion:**
Look at the video about the CSS Grid property.
